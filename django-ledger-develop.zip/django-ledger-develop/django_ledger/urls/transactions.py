from django.urls import path

from django_ledger import views

urlpatterns = []
