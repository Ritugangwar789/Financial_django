from django.apps import AppConfig


class DjangoLedgerGraphqlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_ledger_graphene'
